About Splendio Theme
====================
Splendio is a fixed width (980px) theme. The theme is not dependent on any 
core theme. Its very light weight for fast loading with modern look.
 * 2 column.
 * Multi Level Drop Down menu.
 * 10+ collapsible blocks region
 * Tableless
 * Use of Google Web Fonts
 * Integrated Twitter and Facebook icons. Manage it from theme settings page.
 * Breadcrumb navigation. Show / hide from theme settings
 * Footer website copyright text. Show / hide from theme settings
 * Footer Mega Menu. Show / hide from theme settings

Note
=======
After installing the theme, Move the Search form block to "Search box" block 
region at block configuration page (using "admin/structure/block") and give
the permission "Use search" to all user roles (using "admin/people/permissions").

Browser compatibility:
=====================
The theme has been tested on following browsers. IE7+, Firefox, Google Chrome, Opera.

Drupal compatibility:
=====================
This theme is compatible with Drupal 7.x.x

Help and Support Us
=====================
Please consider a small donation 
https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=saran.nanosoft%40gmail%2ecom&lc=US&item_name=Saran&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Paypal ID : saran.nanosoft@gmail.com
